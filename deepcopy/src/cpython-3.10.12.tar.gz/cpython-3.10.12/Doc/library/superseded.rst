.. _superseded:

******************
Superseded Modules
******************

The modules described in this chapter are deprecated and only kept for
backwards compatibility. They have been superseded by other modules.


.. toctree::

   aifc.rst
   asynchat.rst
   asyncore.rst
   audioop.rst
   cgi.rst
   cgitb.rst
   chunk.rst
   crypt.rst
   imghdr.rst
   imp.rst
   mailcap.rst
   msilib.rst
   nis.rst
   nntplib.rst
   optparse.rst
   ossaudiodev.rst
   pipes.rst
   smtpd.rst
   sndhdr.rst
   spwd.rst
   sunau.rst
   telnetlib.rst
   uu.rst
   xdrlib.rst
